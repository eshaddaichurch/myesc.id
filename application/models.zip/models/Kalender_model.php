<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kalender_model extends CI_Model {


}

/* End of file Kalender_model.php */
/* Location: ./application/models/Kalender_model.php */