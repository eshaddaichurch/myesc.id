<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * File ini TIDAK boleh masuk Git. Sudah ditambahkan ke .gitignore.
 * Taruh file ini manual di server via SFTP/cPanel saat deploy,
 * jangan pernah commit / push.
 *
 * Ganti 'GANTI_DENGAN_PASSWORD_BARU_...' dengan password baru
 * (bukan password lama yang sudah bocor).
 */

$smtp_credentials = [
    // 'nextstep' => [
    //     'user' => 'nextstep@myesc.id',
    //     'pass' => 'GANTI_DENGAN_PASSWORD_BARU_NEXTSTEP',
    // ],
    'connect' => [
        'user' => 'connect@myesc.id',
        'pass' => 'ElshaddaiChurch1',
    ],
];